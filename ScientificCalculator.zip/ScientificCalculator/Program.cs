﻿using ArithmeticOperations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PowerOperations;

namespace ScientificCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperations.Arithmetic arithmetic = new ArithmeticOperations.Arithmetic();
            PowerOperations.Power power = new PowerOperations.Power();

            string exp = Console.ReadLine();

            string[] part = exp.Split(' ');

            double n1 = double.Parse(part[0]);
            string operations = parts[1];

            switch (operations)
            {
                case "+":
                    double sum2 = double.Parse(part[2]);
                    Console.WriteLine("=\n" + arithmetic.Sum(n1, sum2));
                    break;

                case "-":
                    double sub2 = double.Parse(parts[2]);
                    Console.WriteLine("=\n" + arithmetic.Subtract(n1, sub2));
                    break;

                case "*":
                    double prod2 = double.Parse(parts[2]);
                    Console.WriteLine("=\n" + arithmetic.Multiply(n1, prod2));
                    break;

                case "/":
                    double div2 = double.Parse(parts[2]);
                    if (div2 == 0)
                    {
                        Console.WriteLine("Cannot divide by zero");
                    }
                    else
                    {
                        Console.WriteLine("=\n" + arithmetic.Divide(n1, div2));
                    }
                    break;

                case "%":
                    double mod2 = double.Parse(parts[2]);                  
                    Console.WriteLine("=\n" + arithmetic.Modulus(n1, mod2));
                    break;

                case "x3":
                    Console.WriteLine("=\n" + power.Cube(n1));
                    break;

                case "x²":
                    Console.WriteLine("=\n" + power.Sq(n1));
                    break;

                case "√":
                    Console.WriteLine("=\n" + power.SquareRoot(n1));
                    break;

                case "3√":
                    Console.WriteLine("=\n" + power.CubeRoot(n1));
                    break;

                case "xⁿ":
                    double exp2 = double.Parse(parts[2]);
                    Console.WriteLine("=\n" + power.Exponent(n1, exp2));
                    break;

                case "x^(1/y)":
                    double fracexp2 = double.Parse(parts[2]);
                    Console.WriteLine("=\n" + power.FractionalExponent(n1, fracexp2));
                    break;

                default:
                    Console.WriteLine("Invalid Operation");
                    break;
            }
        }
    }
}

// x³=alt+0179,xⁿ=alt+252,√=alt+251,