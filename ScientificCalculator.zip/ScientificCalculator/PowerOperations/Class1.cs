﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerOperations
{
    public class Power
    {
        public double Cube(double n1)
        {
            return n1 * n1 * n1;
        }
        public double Sq(double n1)
        {
            return n1 * n1;
        }
        public double SquareRoot(double n1)
        {
            if (n1 < 2)
                return n1;

            double a = n1;
            double b = (a + (n1 / a)) / 2;

            while (Math.Abs(a - b) >= 0.00001)
            {
                a = b;
                b = (a + (n1 / a)) / 2;
            }
            return b; ;
        }
        public double CubeRoot(double n1)
        {
            if (n1 < 2)
                return n1;

            double a = n1;
            double b = (a + (n1 / a)) / 3;

            while (Math.Abs(a - b) >= 0.00001)
            {
                a = b;
                b = (a + (n1 / b)) / 3;
            }
            return b;
        }
        public double Exponent(double expVal, double baseNum)
        {
            if (expVal == 0)
                return 1;

            double result = 1;
            if (expVal < 0)
            {
                baseNum = 1 / baseNum;
                expVal = -expVal;
            }
            for (int i = 0; i < expVal; i++)
            {
                result *= baseNum;
            }
            return result;
        }
        public double FractionalExponent(double baseNum, double expVal)
        {
            double smallPosVal = 0.00001;
            double guess = baseNum / 2.0;
            double previousGuess;
            do
            {
                previousGuess = guess;
                guess = ((expVal - 1.0) * previousGuess + (baseNum / Math.Pow(previousGuess, expVal - 1))) / expVal;
            } while (Math.Abs(guess - previousGuess) >= smallPosVal);

            return guess;
        }
    }
}
